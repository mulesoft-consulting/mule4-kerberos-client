package org.mule.extension.krb.client.internal;


import java.util.Base64;
import java.io.File;
import java.security.Principal;
import java.security.PrivilegedAction;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.security.auth.DestroyFailedException;
import javax.security.auth.Subject;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.TextOutputCallback;
import javax.security.auth.kerberos.KerberosKey;
import javax.security.auth.kerberos.KerberosPrincipal;
import javax.security.auth.kerberos.KeyTab;
import javax.security.auth.login.AppConfigurationEntry;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import org.ietf.jgss.GSSContext;
import org.ietf.jgss.GSSException;
import org.ietf.jgss.GSSManager;
import org.ietf.jgss.GSSName;
import org.ietf.jgss.Oid;

import static java.lang.Boolean.TRUE;

import static org.mule.runtime.extension.api.annotation.param.MediaType.ANY;

import org.mule.runtime.extension.api.annotation.param.MediaType;
import org.mule.runtime.extension.api.annotation.param.Config;

/**
 * This class is a container for operations, every public method in this class
 * will be taken as an extension operation.
 */
public class KrbclientOperations {
	
	
	  private static final String SECURITY_AUTH_MODULE_KRB5_LOGIN_MODULE =
	            "com.sun.security.auth.module.Krb5LoginModule";
	    
	    private final static Oid KERB_V5_OID;
	    private final static Oid KRB5_PRINCIPAL_NAME_OID;

	       
	    static {
	        try
	        {
	            KERB_V5_OID = new Oid("1.2.840.113554.1.2.2");
	            KRB5_PRINCIPAL_NAME_OID = new Oid("1.2.840.113554.1.2.2.1");

	        } catch (final GSSException ex)
	        {
	            throw new Error(ex);
	        }
	    }
	    
	   // private static File keytabFile= new File("C:\\Users\\N904352\\eclipse-workspace\\testClient\\src\\main\\resources\\DP_Dev_DMV_GID00251.keytab");
	            
	   // private static File keytabFile;
	    
//	    public static String getOsName()
//	    {
//	    	String OS = null;
//	       if(OS == null) { OS = System.getProperty("os.name"); }
//	       return OS;
//	    }

	/**
	 * Example of a simple operation that receives a string parameter and
	 * returns a new string message that will be set on the payload.
	 * @throws Exception 
	 */
	@MediaType(value = ANY, strict = false)
	public String ticket(@Config KrbclientConfiguration config) throws Exception {
		
		String keyTabLocation = config.getKeyTabLocation();
		String clientPrincipal = config.getClientPrincipal();
		String serverPrincipal = config.getServerPrincipal();
		boolean useCanonicalHostnames = config.isUseCanonicalHostnames();
		
		return doKrbAuthentication(keyTabLocation, clientPrincipal,serverPrincipal, useCanonicalHostnames);
	}

	/**
	 * Private Methods are not exposed as operations
	 * @throws Exception 
	 */
	private String doKrbAuthentication(String keyTabLocation, String clientPrincipal,String serverPrincipal, boolean useCanonicalHostnames) throws Exception {
		
	
		
//		System.out.println("keyTabLocation: " + keyTabLocation);
//		System.out.println("clientPrincipal: " + clientPrincipal);
//		System.out.println("serverPrincipal: " + serverPrincipal);
//		System.out.println("useCanonicalHostnames: " + new Boolean(useCanonicalHostnames).toString());
		
		String kerberosToken= kerberosAuthenticate(keyTabLocation,clientPrincipal,serverPrincipal);
		StringBuilder sb = new StringBuilder();
		sb.append("Negotiate ").append(kerberosToken);
		
		return sb.toString();

	}
	
	private String kerberosAuthenticate(String keyTabLocation,String ClientPrincipal,String ServerPrincipal) throws Exception
	{
		
		 File keytabFile=null;             		 
		 
		
		  //String operSystem = System.getProperty("os.name").toLowerCase();
		 // System.out.print(operSystem);
		  
		   // Note- Local Testing 
	        
		/*	if (operSystem.indexOf("linux") >= 0)   
			{			
			      keytabFile = new File("/home/n904352/DP_Dev_DMV_GID00251.keytab");				 
			     // System.out.print(keytabFile.getAbsolutePath());
			}
			else
			{	
			      keytabFile = new File("C:\\Projects\\Kerberos\\DP_Dev_DMV_GID00251.keytab");		
				//  System.out.print(keytabFile.getAbsolutePath());
				   
			}*/
			
			  keytabFile = new File(keyTabLocation);
			
			
			
			//String serverPrincipal = "HTTP/mrmdev.ace.aaaclubnet.com@ACE.AAACLUBNET.COM";
				
			KerberosPrincipal principal = new KerberosPrincipal(ClientPrincipal);
			
	        final KeyTab keytab = getKeyTab(principal, keytabFile);

	        // Krb5LoginModule doesn't seem to accept the keytab file on input.
	        final Set<Principal> principals = Collections.<Principal> singleton(principal);
	        final Set<?> pubCredentials = Collections.emptySet();
	        final Set<?> privCredentials = Collections.<Object> singleton(keytab);
	        Subject subject = new Subject(false, principals, pubCredentials, privCredentials);

	        final String serviceName = ServerPrincipal;

	        final LoginContext lc = new LoginContext(serviceName, subject, new CallbackHandler() {
	            public void handle(Callback[] callbacks) {
	                for (Callback callback : callbacks) {
	                    if (callback instanceof TextOutputCallback) {
	                    //    LOG.error(((TextOutputCallback) callback).getMessage());
	                    }
	                }
	            }
	        }, new Krb5WithKeytabLoginConfiguration(serviceName, principal, keytabFile));
			
			
	        lc.login();
		    		
	       // byte[] kerberosTicket;
	        subject = lc.getSubject();
		    KerberosPrincipal krbPrincipal = subject.getPrincipals(KerberosPrincipal.class).iterator().next();

	        final GSSManager manager = GSSManager.getInstance();
	        final GSSName clientName = manager.createName(krbPrincipal.toString(), KRB5_PRINCIPAL_NAME_OID);
	        final GSSName serverName = manager.createName(ServerPrincipal, KRB5_PRINCIPAL_NAME_OID);

	        final GSSContext context = manager.createContext(serverName,
	                KERB_V5_OID,
	                null,
	                GSSContext.DEFAULT_LIFETIME);
	        context.requestMutualAuth(false);
	        context.requestConf(false);
	        context.requestInteg(true);
	       
	        byte[] serviceTicket;
	        byte[] token = new byte[0];
	    
	        
	        serviceTicket = Subject.doAs( subject, new PrivilegedAction<byte[]>() {
	            public byte[] run() {
	              try {
	             
	                // This is a one pass context initialisation.
	                context.requestMutualAuth(false);
	                context.requestConf(false);
	                context.requestInteg(true);                            
	                
	                final byte[] outToken =  context.initSecContext( token, 0, token.length);
	                return outToken;
	              }
	              catch ( GSSException e) {
	                e.printStackTrace();
	                return null;
	              }
	            }
	          });
	               

            String base64Token = null;
            
	        if (token !=null)
	        {
//	        	  System.out.print(String.format("Src Name: %s\n", context.getSrcName()));
//	        	  System.out.print(String.format("Target  : %s\n", context.getTargName()));
	            base64Token = Base64.getEncoder().encodeToString(serviceTicket);
	            	            
//	            System.out.print((base64Token));
//	            System.out.print("\n");
	            
	            
	        }

	        context.dispose();
			return base64Token;		
		
		
	}
	
   
    /**
     * Load KeyTab. getJaasDataSource() will store this value in the Subject's private credentials.
     * getHadoopDataSource() only uses this method to verify that an appropriate keytab file was
     * specified.
     *
     * @param principal
     * @param keytabFile
     * @return
     * @throws LoginException
     */
    static KeyTab getKeyTab(KerberosPrincipal principal, File keytabFile) throws LoginException {

        if (!keytabFile.exists() || !keytabFile.canRead()) {
            throw new LoginException("specified file does not exist or is not readable.");
        }

        // verify keytab file exists
        final KeyTab keytab = KeyTab.getInstance(principal, keytabFile);
        if (!keytab.exists()) {
            throw new LoginException("specified file is not a keytab file.");
        }

        // verify keytab file actually contains at least one key for this principal.
        final KerberosKey[] keys = keytab.getKeys(principal);
        if (keys.length == 0) {
            throw new LoginException(
                    "specified file does not contain at least one key for this principal.");
        }

        // destroy keys since we don't need them, we just need to make sure they exist.
        for (KerberosKey key : keys) {
            try {
                key.destroy();
            } catch (DestroyFailedException e) {
            //    LOG.debug("unable to destroy key");
            }
        }

        return keytab;
    }

    /**
     * Class that allows us to pull JAAS configuration values from a Map instead of an external
     * .conf file.
     */
    static class CustomLoginConfiguration extends javax.security.auth.login.Configuration {
        private final Map<String, AppConfigurationEntry> entries = new HashMap<>();

        public CustomLoginConfiguration(Map<String, Map<String, String>> params) {
            for (Map.Entry<String, Map<String, String>> entry : params.entrySet()) {
                entries.put(entry.getKey(),
                        new AppConfigurationEntry(SECURITY_AUTH_MODULE_KRB5_LOGIN_MODULE,
                                AppConfigurationEntry.LoginModuleControlFlag.REQUIRED,
                                entry.getValue()));
            }
        }

        /**
         * Get entry.
         */
        @Override
        public AppConfigurationEntry[] getAppConfigurationEntry(String name) {
            if (entries.containsKey(name)) {
                return new AppConfigurationEntry[] { entries.get(name) };
            }
            return new AppConfigurationEntry[0];
        }
    }

    /**
     * Convenience class for Kerberos + Keytab JAAS configuration.
     */
    static class Krb5WithKeytabLoginConfiguration extends CustomLoginConfiguration {

        /**
         * Constructor taking basic Kerberos properties.
         *
         * @param serviceName JAAS service name
         * @param principal Kerberos principal
         * @param keytabFile keytab file containing key for this principal
         */
        public Krb5WithKeytabLoginConfiguration(String serviceName, KerberosPrincipal principal,
                File keytabFile) {
            super(Collections.singletonMap(serviceName, makeMap(principal, keytabFile)));
        }

        /**
         * Static method that creates the Map required by the parent class.
         *
         * @param principal Kerberos principal
         * @param keytabFile keytab file containing key for this principal
         */
        private static Map<String, String> makeMap(KerberosPrincipal principal, File keytabFile) {
            final Map<String, String> map = new HashMap<>();

            // this is the basic Kerberos information
            map.put("principal", principal.getName());
            map.put("useKeyTab", TRUE.toString());
            map.put("keyTab", keytabFile.getAbsolutePath());
            //map.put("debug", TRUE.toString());

            // 'fail fast'
           // map.put("refreshKrb5Config", TRUE.toString());

            // we're doing everything programmatically so we never want to prompt the user.
            map.put("doNotPrompt", TRUE.toString());
            return map;
        }
    }
	
	
}
