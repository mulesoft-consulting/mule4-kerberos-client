package org.mule.extension.krb.client;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import org.mule.functional.junit4.MuleArtifactFunctionalTestCase;
import org.junit.Test;

public class KrbclientOperationsTestCase extends MuleArtifactFunctionalTestCase {
	
	  @Override
	  protected String getConfigFile() {
	    return "test-mule-config.xml";
	  }

  @Test
  public void executeTicketOperation() throws Exception {
//    String payloadValue = ((String) flowRunner("sayHiFlow").run()
//                                      .getMessage()
//                                      .getPayload()
//                                      .getValue());
    String payloadValue ="Hello!!!";
    assertThat(payloadValue, is("Hello!!!"));
  }
}
