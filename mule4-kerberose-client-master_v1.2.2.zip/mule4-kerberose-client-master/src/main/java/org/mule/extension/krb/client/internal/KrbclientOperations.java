package org.mule.extension.krb.client.internal;


import java.util.Base64;
import java.io.File;
import java.security.Principal;
import java.security.PrivilegedAction;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.security.auth.DestroyFailedException;
import javax.security.auth.Subject;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.TextOutputCallback;
import javax.security.auth.kerberos.KerberosKey;
import javax.security.auth.kerberos.KerberosPrincipal;
import javax.security.auth.kerberos.KeyTab;
import javax.security.auth.login.AppConfigurationEntry;
import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;

import org.ietf.jgss.GSSContext;
import org.ietf.jgss.GSSException;
import org.ietf.jgss.GSSManager;
import org.ietf.jgss.GSSName;
import org.ietf.jgss.Oid;

import static java.lang.Boolean.TRUE;

import static org.mule.runtime.extension.api.annotation.param.MediaType.ANY;

import org.mule.runtime.extension.api.annotation.param.MediaType;
import org.mule.runtime.extension.api.annotation.param.Config;

import com.kerb4j.client.SpnegoContext;
import com.kerb4j.client.SpnegoClient;

/**
 * This class is a container for operations, every public method in this class
 * will be taken as an extension operation.
 */
public class KrbclientOperations {
	

	/**
	 * Example of a simple operation that receives a string parameter and
	 * returns a new string message that will be set on the payload.
	 * @throws Exception 
	 */
	@MediaType(value = ANY, strict = false)
	public String ticket(@Config KrbclientConfiguration config) throws Exception {
		
		String keyTabLocation = config.getKeyTabLocation();
		String clientPrincipal = config.getClientPrincipal();
		//String serverPrincipal = config.getServerPrincipal();
		//boolean useCanonicalHostnames = config.isUseCanonicalHostnames();
		
		return doKrbAuthentication(keyTabLocation, clientPrincipal);
	}

	/**
	 * Private Methods are not exposed as operations
	 * @throws Exception 
	 */
	private String doKrbAuthentication(String keyTabLocation, String clientPrincipal) throws Exception {
		
	
		String kerberosToken = null;
		SpnegoContext ctx = null;
		SpnegoClient client = null;
		
		try {
		
			client = SpnegoClient.loginWithKeyTab(clientPrincipal, keyTabLocation);
			ctx = client.createContextForSPN(clientPrincipal);
			kerberosToken = ctx.createTokenAsAuthroizationHeader();

		

		} finally {
			ctx.close();
			ctx = null;
			client = null;
		}

		return kerberosToken;
		
	}

}
