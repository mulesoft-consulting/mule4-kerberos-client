package org.mule.extension.krb.client.internal;

import org.mule.runtime.extension.api.annotation.Configuration;
import org.mule.runtime.extension.api.annotation.Operations;
import org.mule.runtime.extension.api.annotation.connectivity.ConnectionProviders;
import org.mule.runtime.extension.api.annotation.param.Parameter;

/**
 * This class represents an extension configuration, values set in this class
 * are commonly used across multiple operations since they represent something
 * core from the extension.
 */
@Operations(KrbclientOperations.class)
public class KrbclientConfiguration {

	@Parameter
	private String keyTabLocation;

	@Parameter
	private String clientPrincipal;

	public String getKeyTabLocation() {
		return keyTabLocation;
	}

	public void setKeyTabLocation(String keyTabLocation) {
		this.keyTabLocation = keyTabLocation;
	}

	public String getClientPrincipal() {
		return clientPrincipal;
	}

	public void setClientPrincipal(String clientPrincipal) {
		this.clientPrincipal = clientPrincipal;
	}

}
