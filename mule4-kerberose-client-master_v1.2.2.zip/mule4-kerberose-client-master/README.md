# mule4-kerberos-client Extension

This is a Kerberos client that authenticates with a Key Distribution Center (KDC) to obtain a Kerberos ticket. The ticket
is returned in an authorization header format (Negotiate type).

This is an example of using this connector in a Mule flow:

```xml
			<krb-client:ticket doc:name="Ticket"  target="authorization-hdr" />
			<http:request config-ref="request_api_configuration" method="GET" path="/search" doc:name="Request">
				<http:headers><![CDATA[#[output application/java
---
{
	"Authorization" : vars.'authorization-hdr'
}]]]></http:headers>
				<http:response-validator>
					<http:success-status-code-validator values="0..599" />
				</http:response-validator>
			</http:request>

```

Add this dependency to your application pom.xml

```
		<dependency>
			<groupId>01a4664d-9e16-454b-a14c-59548ef896b5</groupId>
			<artifactId>mule4-kerberos-client</artifactId>
			<classifier>mule-plugin</classifier>
			<version>1.0.1</version>
		</dependency>
```
